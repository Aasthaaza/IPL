export const environment = {
  production: false,
  apiUrl: window.origin.replace("3000", "") + "/proxy/5000",
};
