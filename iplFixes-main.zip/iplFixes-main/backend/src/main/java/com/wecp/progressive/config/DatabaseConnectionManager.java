package com.wecp.progressive.config;
 
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
 
public class DatabaseConnectionManager {
private static final Properties properties = new Properties();
static{
    loadProperties();
}
private static void loadProperties(){
    try (InputStream input = DatabaseConnectionManager.class.getClassLoader().getResourceAsStream("application.properties")) {
        if(input == null){
            throw new IllegalStateException("resource.properties not found in classpath");
        }
        properties.load(input);
    } catch (IOException e) {
        throw new RuntimeException("Error loading properties file",e);
    }
}
public static Connection getConnection() throws SQLException{
    return DriverManager.getConnection(properties.getProperty("spring.datasource.url"), properties.getProperty("spring.datasource.username"), properties.getProperty("spring.datasource.password"));
}
}