package com.wecp.progressive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IplApplication {
    public static void main(String[] args) {
        System.out.println("Welcome to Ipl Progressive Project!");
        SpringApplication.run(IplApplication.class, args);
    }
}



